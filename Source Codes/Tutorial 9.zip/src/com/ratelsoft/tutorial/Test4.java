package com.ratelsoft.tutorial;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Test4 {

	public static void main(String[] args) {
		MyFrame frame = new MyFrame("Components Test");
		JPanel panel = new JPanel();
		frame.setContentPane(panel);
		
		final JPasswordField field = new JPasswordField(15);
		final JTextField field2 = new JTextField(15);
		
		JButton button = new JButton("Show Password");
		
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				field2.setText(new String(field.getPassword()));
			}
		});
		
		panel.add(field);
		panel.add(field2);
		panel.add(button);

		frame.setVisible(true);
	}

}
