package com.ratelsoft.tutorial;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class Test3 {

	
	public static void main(String[] args) {
		MyFrame frame = new MyFrame("Components Test");
		JPanel panel = new JPanel();
		frame.setContentPane(panel);
		
		JTextField textField = new JTextField();
		JTextField textField2 = new JTextField("this is a text");
		JTextField textField3 = new JTextField(20);
		final JTextField textField4 = new JTextField("this is another text with a very long entry hgdtrh hytrvhnhg", 20);
		
		textField3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				System.out.println( ((JTextField) event.getSource()).getText() );
				
				textField4.setSize(new Dimension(350, textField4.getHeight()));
				textField4.setText( ((JTextField) event.getSource()).getText() );
			}
		});
		
		panel.add(textField);
		panel.add(textField2);
		panel.add(textField3);
		panel.add(textField4);
		
		frame.setVisible(true);
	}

}
