package com.ratelsoft.tutorial;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Test2  implements ActionListener{
	private static ButtonGroup group;
	
	public static void main(String[] args) {
		MyFrame frame = new MyFrame("Components Test");
		JPanel panel = new JPanel();
		frame.setContentPane(panel);
		
		group = new ButtonGroup();
		JRadioButton rb1 = new JRadioButton("Male");
		JRadioButton rb2 = new JRadioButton("Female", true);
		JRadioButton rb3 = new JRadioButton("Prefer not to answer");
		
		group.add(rb1);
		group.add(rb2);
		group.add(rb3);
		
		panel.add(rb1);
		panel.add(rb2);
		panel.add(rb3);
		
		Test2 t = new Test2();
		
		JButton clearButton = new JButton("Clear Selection");
		clearButton.addActionListener(t);
		
		JButton findButton = new JButton("Find Selected");
		findButton.addActionListener(t);
		
		panel.add(clearButton);
		panel.add(findButton);
		
		frame.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		if( ev.getActionCommand().equals("Clear Selection") )
			group.clearSelection();
		else{
			Enumeration<AbstractButton> elements = group.getElements();
			
			while( elements.hasMoreElements() ){
				JRadioButton button = (JRadioButton) elements.nextElement();
				
				if( button.isSelected() ){
					System.out.println(button.getText() + " was selected");
					break;
				}
			}
		}
	}

}
