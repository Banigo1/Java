package com.ratelsoft.tutorial;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Test implements ActionListener{
	private static JCheckBox checkbox;

	public static void main(String[] args) {
		//jcombobox
		//radio buttons
		//check boxes
		//jtextfield
		//jpasswordfield
		//JTextComponent
		
		MyFrame frame = new MyFrame("Components Test");
		JPanel panel = new JPanel();
		frame.setContentPane(panel);
		
		checkbox = new JCheckBox("Accept Terms");
		checkbox.setHorizontalTextPosition(SwingConstants.LEFT);
		checkbox.addActionListener(new Test());
		checkbox.setFocusable(false);
		
		checkbox.setSelected(true);
		
		panel.add(checkbox);
		
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		System.out.println(checkbox.isSelected() ? "Checkbox is selected" : "Checkbox is deselected");
	}

}
