package com.ratelsoft.tutorial.common;

public enum Property {
	MOUSE_CLICK_EVENT, ACTION_EVENT, KEYBOARD_EVENT, MEMBERS;
}
