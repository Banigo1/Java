package com.ratelsoft.tutorial;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class Test3 {
	public static void main(String[] args){
		final JFrame frame = new JFrame("Simple Frame");
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				frame.setVisible(true);
			}
		});
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				frame.add(new JLabel(frame.getInsets().top + ""));
				System.out.println("Top Inset is: " + frame.getInsets().top);
				System.out.println("Bottom Inset is: " + frame.getInsets().bottom);
				System.out.println("Left Inset is: " + frame.getInsets().left);
				System.out.println("Right Inset is: " + frame.getInsets().right);
			}
		});
	}
}
