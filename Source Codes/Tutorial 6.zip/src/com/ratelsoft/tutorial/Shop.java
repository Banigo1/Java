package com.ratelsoft.tutorial;

public class Shop {
	private final int item1 = 1;
	private final int item2 = 2;
	private final int item3 = 3;
	private final double item1Price = 1200;
	private final double item2Price = 5000;
	private final double item3Price = 760;
	
	public Shop(){
		
	}
	
	/*
	public double buy(int itemCode){
		switch( itemCode ){
			case item1: return item1Price;
			case item2: return item2Price;
			case item3: return item3Price;
		}
		return 0;
	}
	*/
	
	public double buy(Item item){
		switch( item ){
			case MOBILE_PHONE: return Item.MOBILE_PHONE.getPrice();
			case SHIRT:  return Item.SHIRT.getPrice();
			case TROUSER: return Item.TROUSER.getPrice();
		}
		
		return 0;
	}
}
