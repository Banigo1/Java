package com.ratelsoft.tutorial;

public enum Item {
	SHIRT(589), TROUSER(5670), MOBILE_PHONE(3210);
	
	private double price;
	
	Item(double amount){
		price = amount;
	}
	
	public double getPrice(){
		return price;
	}
}
