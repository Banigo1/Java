package com.ratelsoft.tutorial;

public class Test5 {
	public static void main(String[] args){
		//JFrame - BorderLayout
		//NORTH, SOUTH, EAST, WEST, CENTER
		//FlowLayout
		MyFrame f = new MyFrame();
	}
}
