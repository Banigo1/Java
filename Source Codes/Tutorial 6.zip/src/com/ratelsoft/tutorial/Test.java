package com.ratelsoft.tutorial;

public class Test {

	public static void main(String[] args) {
		Shop shop = new Shop();
		
		System.out.println(shop.buy(Item.MOBILE_PHONE));
	}

}
