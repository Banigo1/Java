package com.ratelsoft.tutorial;

import javax.swing.JFrame;

public class Test2 {

	public static void main(String[] args) {
		//JFrame
		//JPanel
		//Layout Managers FlowLayout, BorderLayout, GridLayout, BoxLayout, GridBagLayout, CardLayout
		//AWT, SWING
		//JLabel
		//JButton
		//JCheckBox
		//JRadioButton
		//JTextField
		//JPasswordField
		//JTextArea
		//JComboBox
		//JDialog
		//UIManager
		//JMenu, JMenuBar, JMenuItem, JMenuCheckBoxItem, JMenuRadioButtonItem
		//JList
		//JTable
		//JTree
		
		JFrame frame = new JFrame("Simple Frame");
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.setVisible(true);
	}

}
