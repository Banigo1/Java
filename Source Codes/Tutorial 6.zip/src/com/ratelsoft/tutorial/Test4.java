package com.ratelsoft.tutorial;

public class Test4 {
	public static void main(String[] args){
		MyFrame f = new MyFrame();
		f.setVisible(true);
	}
}
