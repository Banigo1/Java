package com.ratelsoft.tutorial;

import java.util.HashMap;
import java.util.Map;

public class Test2 {
	public static void main(String[] args){
		Map<String, String> map = new HashMap<String, String>();
		map.put("username", "richboy");
		map.put("password", "hidden");
		
		
	}
}
