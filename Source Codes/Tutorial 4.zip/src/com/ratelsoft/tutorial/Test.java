package com.ratelsoft.tutorial;

import java.util.HashMap;
import java.util.Map;

public class Test {
	public static void main(String[] args){
		//Map
		//Iterator
		//HashMap
		//Internal classes - regular and static
		//private constructor
		//Abstract classes
		//Interfaces
		//GUI
		
		Map<String, String> map = new HashMap<String, String>();
		
		String oldValue = map.put("username", "richboy");
		System.out.println(oldValue == null ? "NULL" : oldValue);
		
		oldValue = map.put("username", "david");
		System.out.println(oldValue == null ? "NULL" : oldValue);
		
		map.put("password", "hidden");
		
		/*
		if( map.containsKey("name") )
			System.out.println("Key found");
		else
			System.out.println("Key not found");
			*/
		System.out.println( map.get("username") );
	}
}
