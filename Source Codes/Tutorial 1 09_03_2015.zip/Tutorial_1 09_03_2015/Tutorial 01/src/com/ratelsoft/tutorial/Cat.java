package com.ratelsoft.tutorial;

public class Cat extends Animal{

	public Cat(String color, int age) {
		super(4, color, age, "Cat");
	}

}
