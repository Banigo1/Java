package com.ratelsoft.tutorial;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class Test3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyFrame frame = new MyFrame("GridLayout testing");
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		JLabel label = new JLabel("simple test"){
			public Dimension getPreferredSize(){
				return new Dimension(500, 200);
			}
			public Dimension getMaximumSize(){
				return new Dimension(500, 700);
			}
			
		};
		JLabel label2 = new JLabel("This should be bold this is not bold");
		JLabel label3 = new JLabel("If this is html This should be on an new line");
		JLabel label4 = new JLabel("Label 4");
		JLabel label5 = new JLabel("Label 5");
		JLabel label6 = new JLabel("Label 6");
		JLabel label7 = new JLabel("Label 7");
		
		label.setAlignmentY(Component.TOP_ALIGNMENT);
		
		panel.add(Box.createHorizontalGlue());
		panel.add(label);
		panel.add(Box.createHorizontalGlue());
		/*
		panel.add(Box.createVerticalStrut(5));
		panel.add(label2);
		panel.add(label3);
		panel.add(label4);
		panel.add(label5);
		panel.add(label6);
		panel.add(label7);
		*/
		
		
		setColour(label, Color.BLUE);
		setColour(label2, Color.ORANGE);
		setColour(label3, Color.RED);
		setColour(label4, Color.YELLOW);
		setColour(label5, Color.GRAY);
		setColour(label6, Color.BLACK);
		setColour(label7, Color.WHITE);
		
		frame.getContentPane().add(new JScrollPane(panel));
		
		frame.setVisible(true);
	}
	
	public static void setColour(JLabel label, Color c){
		label.setOpaque(true);
		label.setBackground(c);
	}

}
