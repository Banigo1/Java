package com.ratelsoft.tutorial;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyFrame frame = new MyFrame("GridLayout testing");
		JPanel panel = new JPanel(new GridLayout(2, 0, 20, 5));
		
		JLabel label = new JLabel("simple test");
		JLabel label2 = new JLabel("<html><b>This should be bold</b> this is not bold");
		JLabel label3 = new JLabel("<html>If this is html This should be on an new line");
		JLabel label4 = new JLabel("Label 4");
		JLabel label5 = new JLabel("Label 5");
		JLabel label6 = new JLabel("Label 6");
		JLabel label7 = new JLabel("Label 7");
		
		panel.add(label);
		panel.add(label2);
		panel.add(label3);
		panel.add(label4);
		panel.add(label5);
		panel.add(label6);
		panel.add(label7);
		
		setColour(label, Color.BLUE);
		setColour(label2, Color.ORANGE);
		setColour(label3, Color.RED);
		setColour(label4, Color.YELLOW);
		setColour(label5, Color.GRAY);
		setColour(label6, Color.BLACK);
		setColour(label7, Color.WHITE);
		
		frame.getContentPane().add(panel);
		
		frame.setVisible(true);
	}
	
	public static void setColour(JLabel label, Color c){
		label.setOpaque(true);
		label.setBackground(c);
	}

}
