package com.ratelsoft.tutorial;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Test4 {
	static JButton button, button2;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyFrame frame = new MyFrame("GridLayout testing");
		JPanel panel = new JPanel();
		
		button = new JButton("My Button");
		button.setActionCommand("this button");
		panel.add(button);
		
		button2 = new JButton("Another Button");
		button2.setActionCommand("button 2");
		panel.add(button2);
		
		button.addActionListener(new MyListener());
		button2.addActionListener(new MyListener());
		
		/*
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				if( event.getActionCommand().equals("this button") ){
					System.out.println(event.getActionCommand());
					//JOptionPane.showMessageDialog(null, "i was clicked");
				}
			}
		});
		*/
		
		frame.getContentPane().add(panel);
		
		frame.setVisible(true);
	}
	
	private static class MyListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent ev) {
			/*
			if( ev.getActionCommand().equals("button 2") )
				JOptionPane.showMessageDialog(null, "Another Button was clicked");
			else
				JOptionPane.showMessageDialog(null, "this Button was clicked");
				*/
			if( ev.getSource() == button )
				JOptionPane.showMessageDialog(null, "this Button was clicked");
			else if( ev.getSource() == button2 )
				JOptionPane.showMessageDialog(null, "Button 2 was clicked");
		}
	}

}
