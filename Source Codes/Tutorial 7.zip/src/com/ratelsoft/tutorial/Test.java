package com.ratelsoft.tutorial;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class Test {

	
	public static void main(String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		
		MyFrame frame = new MyFrame("JPanel Test");
		JPanel panel = new JPanel();
		BorderLayout layout = new BorderLayout();
		layout.setHgap(10);
		layout.setVgap(10);
		panel.setLayout(layout);
		
		panel.setOpaque(false);
		panel.setBackground(Color.BLUE);
		frame.getContentPane().add(panel);
		
		JLabel label = new JLabel("simple test");
		JLabel label2 = new JLabel("<html><b>This should be bold</b> this is not bold");
		JLabel label3 = new JLabel("<html>If this is html This should be on an new line");
		JLabel label4 = new JLabel("Label 4");
		JLabel label5 = new JLabel("label 5");
		panel.add(label, BorderLayout.NORTH);
		panel.add(label2, BorderLayout.CENTER);
		panel.add(label3, BorderLayout.EAST);
		panel.add(label4, BorderLayout.WEST);
		panel.add(label5, BorderLayout.SOUTH);
		
		setColour(label, Color.BLUE);
		setColour(label2, Color.ORANGE);
		setColour(label3, Color.RED);
		setColour(label4, Color.YELLOW);
		setColour(label5, Color.GRAY);
		
		frame.setVisible(true);
	}
	
	public static void setColour(JLabel label, Color c){
		label.setOpaque(true);
		label.setBackground(c);
	}

}
