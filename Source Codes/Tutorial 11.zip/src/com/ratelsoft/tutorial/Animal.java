package com.ratelsoft.tutorial;

import java.awt.Color;

public class Animal {
	private String name;
	private Color color;
	private int age;
	
	public Animal(String name, Color c, int age){
		this.name = name;
		this.color = c;
		this.age = age;
	}
	
	public int getAge(){
		return age;
	}
	
	public String toString(){
		return name;
	}
}
