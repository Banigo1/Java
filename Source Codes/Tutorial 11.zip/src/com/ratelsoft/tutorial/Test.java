package com.ratelsoft.tutorial;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Test implements ItemListener, ActionListener{
	static JComboBox<Animal> cb = new JComboBox<Animal>();
	
	public static void main(String[] args) {
		MyFrame f = new MyFrame("ComboBox Testing");
		JPanel p = new JPanel();
		f.setContentPane(p);
		
		cb = new JComboBox<Animal>();
		for( Animal item : getDynamicContent2() )
			cb.addItem(item);
		
		Test t = new Test();
		cb.addItemListener(t);
		
		JButton removeItemBtn = new JButton("Remove First Item");
		removeItemBtn.addActionListener(t);
		
		
		p.add(cb); p.add(removeItemBtn);
		f.setVisible(true);
	}

	public static ArrayList<String> getDynamicContent(){
		ArrayList<String> list = new ArrayList<String>();
		list.add("Peter");
		list.add("Bruno");
		list.add("Scott");
		list.add("Phil");
		
		return list;
	}
	
	public static ArrayList<Animal> getDynamicContent2(){
		ArrayList<Animal> list = new ArrayList<Animal>();
		list.add(new Animal("Dog", Color.BLACK, 4));
		list.add(new Animal("Cat", Color.WHITE, 3));
		list.add(new Animal("Horse", Color.GRAY, 11));
		list.add(new Animal("Man", Color.BLACK, 40));
		
		return list;
	}
	
	public void itemStateChanged(ItemEvent event){
		if(event.getStateChange() == ItemEvent.SELECTED){
			JComboBox<Animal> cb = (JComboBox<Animal>) event.getSource();
			//Animal selected = cb.getItemAt(cb.getSelectedIndex());
			Animal selected = (Animal) cb.getSelectedItem();
			
			JOptionPane.showMessageDialog(null, selected + " is " + selected.getAge() + " years old");
		}
	}

	@Override
	public void actionPerformed(ActionEvent ev) {
		if( cb.getItemCount() > 0 )
			cb.removeItemAt(0);
	}
}
