package com.ratelsoft.tutorial;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Test2 implements ActionListener{
	private static CardLayout manager;
	private static JButton thereButton, hereButton;
	private static JPanel container;
	
	public static void main(String[] args){
		MyFrame f = new MyFrame("CardLayout Testing");
		
		manager = new CardLayout();
		container = new JPanel(manager);
		f.getContentPane().add(container, BorderLayout.CENTER);
		
		JPanel p1 = new JPanel();
		p1.setBackground(Color.RED);
		p1.add(new JLabel("Here"));
		
		JPanel p2 = new JPanel();
		p2.setBackground(Color.BLUE);
		p2.add(new JLabel("There"));
		
		container.add(p1, "hereCard");
		container.add(p2, "thereCard");
		
		Test2 t = new Test2();
		hereButton = new JButton("Go to Here");
		hereButton.addActionListener(t);
		
		thereButton = new JButton("Go There");
		thereButton.addActionListener(t);
		
		JPanel buttonsPanel = new JPanel();
		buttonsPanel.add(hereButton);
		buttonsPanel.add(thereButton);
		
		f.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);
		
		f.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if( e.getSource() == hereButton ){
			manager.show(container, "hereCard");
		}
		else if( e.getSource() == thereButton ){
			manager.show(container, "thereCard");
		}
	}
}
