package com.ratelsoft.tutorial;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Test2 {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	
	public Test2() {
		try{
			try{
				Class.forName("org.sqlite.JDBC").newInstance();
			}
			catch(Exception e){
				Class.forName("org.sqlite.JDBC");
			}
			
			File url = new File( getClass().getResource("files/teamempire.db3").toURI() );
			
			con = DriverManager.getConnection("jdbc:sqlite:" + url.getAbsolutePath());
			ps = con.prepareStatement("SELECT * FROM test");//
			rs = ps.executeQuery();//SELECT statement
			//ps.executeUpdate();//INSERT, UPDATE, DELETE
			
			while( rs.next() ){
				System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("phone") + "\t" + rs.getString("email"));
			}
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws Exception{
		new Test2();
	}
}
