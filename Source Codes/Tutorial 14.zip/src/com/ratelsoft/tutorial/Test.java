package com.ratelsoft.tutorial;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Test {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	
	public Test() {
		try{
			try{
				Class.forName("com.mysql.jdbc.Driver").newInstance();
			}
			catch(Exception e){
				Class.forName("com.mysql.jdbc.Driver");
			}
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamempire", "root", "");
			ps = con.prepareStatement("SELECT * FROM test", ResultSet.TYPE_SCROLL_INSENSITIVE);//
			rs = ps.executeQuery();//SELECT statement
			//ps.executeUpdate();//INSERT, UPDATE, DELETE
			
			while( rs.next() ){
				System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("phone") + "\t" + rs.getString("email"));
			}
			rs.absolute(1);
			System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("phone") + "\t" + rs.getString("email"));
			//System.out.println(rs.getRow());
			
			rs.close();
			ps.close();
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws Exception{
		//Test t = new Test();
		Class.forName("com.ratelsoft.tutorial.Test").newInstance();
		
	}
}
