package com.ratelsoft.tutorial;

import java.sql.PreparedStatement;

public class Query {
	private PreparedStatement ps;
	public Query(String query){
		
	}
	
	public PreparedStatement getPS(){
		return ps;
	}
	
	public void disconnect(){
		
	}
}