package com.ratelsoft.tutorial;

import java.sql.ResultSet;

public class Test3 {
	public static void main(String[] args) throws Exception{
		Query q = new Query("INSERT INTO test VALUES (NULL, 'sample name', '24854345', 'me@you.com')");
		q.getPS().executeUpdate();
		q.disconnect();
	}
}
