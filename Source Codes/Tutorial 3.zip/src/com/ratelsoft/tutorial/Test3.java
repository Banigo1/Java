package com.ratelsoft.tutorial;

public class Test3 {
	public static void main(String[] args){
		//username = richboy
		//password = hidden
		//remember_me = true/false
		//last_login_time = 1324342325
		
		ValuePair<String, String> usernameSetting = new ValuePair<String, String>("username", "richboy");
		ValuePair<String, String> passwordSetting = new ValuePair<String, String>("password", "hidden");
		ValuePair<String, Boolean> rSetting = new ValuePair<String, Boolean>("remember_me", true);
		ValuePair<String, Long> lSetting = new ValuePair<String, Long>("remember_me", 153673l);
		
		Animal an = new Animal(4, "Black", 4, "Dog");
		ValuePair<String, Animal> animal = new ValuePair<String, Animal>("animal", an);
		
		System.out.println(usernameSetting.getValue());
		System.out.println(passwordSetting.getValue());
		System.out.println(rSetting.getValue());
		System.out.println(lSetting.getValue());
		System.out.println(animal.getValue());
		
		System.out.println(animal.getValue().getName());
	}
}
