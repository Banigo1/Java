package com.ratelsoft.tutorial;

public class ValuePair<T, E> {
	private T elem1;
	private E elem2;
	
	public ValuePair(T e1, E e2){
		elem1 = e1;
		elem2 = e2;
	}
	
	public T getKey(){
		return elem1;
	}
	
	public E getValue(){
		return elem2;
	}
}
