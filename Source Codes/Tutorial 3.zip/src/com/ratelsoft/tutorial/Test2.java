package com.ratelsoft.tutorial;

public class Test2 {
	public static void main(String[] args){
		Integer[] intArray = {5, 6, 7, 9};
		String[] names = {"Paul", "Phil", "Lambert"};
		Double[] scores = {56.7, 99.0, 43.2, 50.0, 78.1};
		
		/*
		printArray(intArray);
		printArray(names);
		printArray(scores);
		*/
		
		Man man = new Man(45);
		printArray(man);
	}
	
	public static <T> void printArray(T[] array){
		for( T var : array )
			System.out.print(var + ", ");
		System.out.println();
	}

	public static <T extends Animal> void printArray(T element){
		System.out.println( element.getColor() );
	}
}