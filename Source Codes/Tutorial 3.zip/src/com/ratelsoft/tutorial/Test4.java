package com.ratelsoft.tutorial;

import java.util.LinkedList;

public class Test4 {
	public static void main(String[] args){
		//ArrayList
		//LinkedList
		//Map, HashMap
		//Queue, PriorityQueue  FIFO
		//Stack LIFO
		
		/*
		ArrayList<String> names = new ArrayList<String>();
		names.add("jones");
		names.add("andrew");
		names.add("peter");
		
		String elem = names.remove(1);
		
		System.out.println(elem);
		*/
		
		LinkedList<String> names = new LinkedList<String>();
		names.add("jones");
		names.add("andrew");
		names.addFirst("peter");
		
		while( !names.isEmpty() ){
			System.out.println(names.removeLast());
		}
	}
}
