package com.ratelsoft.tutorial;

public class Test {
	public static void main(String[] args){
		try{
			divide(15, 0);
			/*
			 * 
			 * 
			 * 
			 * 
			 */
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		finally{
			
		}
		
		//System.out.println("Method call got here");
	}
	
	public static double divide(int num1, int num2){
		return num1 / num2;
	}
	
	public static void throwException() throws Exception{
		throwException2();
	}
	
	public static void throwException2() throws Exception{
		throw new Exception("Simple exception");
	}
}
