package com.ratelsoft.tutorial;

public class ContractEmployee extends Employee{

	public ContractEmployee(String name, String employeeID, int workHours) {
		super(name, employeeID, workHours);
	}

	@Override
	public double getSalary() {
		return getWorkHours() * PAY_PER_HOUR * 0.8;
	}
}
