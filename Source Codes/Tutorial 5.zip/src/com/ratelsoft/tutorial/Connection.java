package com.ratelsoft.tutorial;

public interface Connection {
	public void connect() throws Exception;
}
