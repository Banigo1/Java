package com.ratelsoft.tutorial;

public class StaffEmployee extends Employee{

	public StaffEmployee(String name, String employeeID, int workHours) {
		super(name, employeeID, workHours);
		
	}

	@Override
	public double getSalary() {
		double salary = PAY_PER_HOUR * getWorkHours();
		
		if( getWorkHours() > 10 )
			salary += 50;//bonus
		
		return salary;
	}
}
