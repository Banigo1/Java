package com.ratelsoft.tutorial;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Test {
	public static void main(String[] args){
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put("username", "richboy");
		map.put("password", "hidden");
		map.put("school", "NDU");
		map.put("address", "3/6 Hazelwood Grove");
		
		
		Set<String> keys = map.keySet();
		for( String key : keys ){
			System.out.println(map.get(key));
		}
		
		Iterator<String> iterator = keys.iterator();
		
		while( iterator.hasNext() ){
			System.out.println(map.get(iterator.next()));
		}
		
		
		Set<Entry<String, String>> key2 = map.entrySet();
		for( Entry<String, String> entry : key2 ){
			System.out.println(entry.getValue());
		}
		
		Iterator<Entry<String, String>> iterator2 = map.entrySet().iterator();
		while( iterator2.hasNext() ){
			System.out.println(iterator2.next().getValue());
		}
	}
}
