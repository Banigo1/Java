package com.ratelsoft.tutorial;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Test4 {
	public static void main(String[] args){
		ArrayList<MyInteger> numbers = new ArrayList<MyInteger>();
		numbers.add(new MyInteger(2));
		numbers.add(new MyInteger(20));
		numbers.add(new MyInteger(3));
		numbers.add(new MyInteger(45));
		numbers.add(new MyInteger(-1));
		
		Collections.sort(numbers);
		for( MyInteger i : numbers ){
			System.out.println(i.getNum());
		}
		
		Collections.sort(numbers, new MyComparator());
		for( MyInteger i : numbers ){
			System.out.println(i.getNum());
		}
		
		Collections.sort(numbers, new Comparator<MyInteger>(){

			@Override
			public int compare(MyInteger o1, MyInteger o2) {
				if( o1.getNum() == o2.getNum() )
					return 0;
				else if( o1.getNum() > o2.getNum() )
					return 1;
				else
					return -1;
			}
			
		});
		
		for( MyInteger i : numbers ){
			System.out.println(i.getNum());
		}
	}
	
	public static class MyComparator implements Comparator<MyInteger>{

		@Override
		public int compare(MyInteger o1, MyInteger o2) {
			if( o1.getNum() == o2.getNum() )
				return 0;
			else if( o1.getNum() > o2.getNum() )
				return -1;
			else
				return 1;
		}
		
	}
	
	public static class MyInteger implements Comparable<MyInteger>{
		private int num;
		
		public MyInteger(int num){
			this.num = num;
		}
		public Integer getNum(){
			return num;
		}
		
		//@Override
		public int compareTo(MyInteger o) {
			if( getNum() == o.getNum() )
				return 0;
			else if( getNum() > o.getNum() )
				return -1;
			else
				return 1;
		}
	}
}
