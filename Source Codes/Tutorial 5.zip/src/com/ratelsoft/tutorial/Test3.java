package com.ratelsoft.tutorial;

import java.util.ArrayList;

import com.ratelsoft.tutorial.Network.Node;

public class Test3 {
	
	public static void main(String[] args){
		Network network = Network.getInstance();
		
		Node node = network.getRootNode();
		printChildren(node);
		
		//System.out.println(network.getNodeCount());
	}
	
	public static void printChildren(Node node){
		if( node.hasMoreElements() ){
			ArrayList<Node> children = new ArrayList<Node>();
			System.out.println("The Children of " + node + " is:");
			System.out.print("\t");
			while( node.hasMoreElements() ){
				Node n = node.nextElement();
				children.add(n);
				System.out.print(n + ", ");
			}
			
			System.out.println();
			
			for( Network.Node n : children )
				printChildren(n);
		}
		else
			System.out.println(node);
	}
}
