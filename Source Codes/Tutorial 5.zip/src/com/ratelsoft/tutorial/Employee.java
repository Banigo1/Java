package com.ratelsoft.tutorial;

public abstract class Employee {
	private String name;
	private String employeeID;
	private int workHours;
	public static final int PAY_PER_HOUR = 50;
	
	public Employee(String name, String employeeID, int workHours){
		this.name = name;
		this.employeeID = employeeID;
		this.workHours = workHours;
	}
	
	public String getName(){
		return name;
	}
	
	public int getWorkHours(){
		return workHours;
	}
	
	public String getID(){
		return employeeID;
	}
	
	public abstract double getSalary();
}
