package com.ratelsoft.tutorial;

public class Test2 {
	public static void main(String[] args){
		Employee contract = new ContractEmployee("Paul Lambert", "EMP001", 35);
		Employee staff = new StaffEmployee("Jay Ray", "EMP002", 35);
		
		System.out.printf("The Salary for the contract staff is %.2f\n", contract.getSalary());
		System.out.printf("The Salary for the full staff is %.2f\n", staff.getSalary());
	}
}
