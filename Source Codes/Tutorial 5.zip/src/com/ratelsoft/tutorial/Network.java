package com.ratelsoft.tutorial;

import java.util.ArrayList;
import java.util.Enumeration;

public class Network {
	private ArrayList<Node> nodes;
	private static Network network;
	private Node rootNode;
	
	private Network(){
		nodes = new ArrayList<Node>();
		createNodes();
	}
	
	public static Network getInstance(){
		if( network == null )
			network = new Network();
		return network;
	}
	
	private void createNodes(){
		rootNode = new Node(null, 0);
		Node childNode1 = new Node(rootNode, 1);
		Node childNode2 = new Node(rootNode, 2);
		new Node(rootNode, 3);
		
		
		new Node(childNode1, 4);
		new Node(childNode1, 5);
		
		Node subChild3 = new Node(childNode2, 6);
		
		new Node(subChild3, 7);
	}
	
	public int getNodeCount(){
		return nodes.size();
	}
	
	public Node getRootNode(){
		return rootNode;
	}
	
	public Node[] getChildNodes(Node node){
		if( node == null )
			return null;
		return node.getChildren();
	}
	
	public Node getNode(int index){
		if( index < nodes.size() )
			return nodes.get(index);
		return null;
	}
	
	public class Node implements Enumeration<Node>{
		private Node parentNode;
		private int nodeID;
		private ArrayList<Node> children;
		
		private Node(Node parent, int id){
			this.parentNode = parent;
			nodeID = id;
			children = new ArrayList<Node>();
			
			nodes.add(this);//add this node as part of the network
			if( parent != null )
				parent.addChild(this);
		}
		
		public void addChild(Node n){
			children.add(n);
		}
		
		public Node[] getChildren(){
			return children.toArray(new Node[0]);
		}
		
		public boolean hasChildren(){
			return children.size() > 0;
		}
		
		public boolean hasParent(){
			return parentNode != null;
		}
		
		public Node getParent(){
			return parentNode;
		}
		
		public int getNodeID(){
			return nodeID;
		}
		
		public int findNodeIndex(){
			int index = 0;
			
			for(int i = 0; i < nodes.size(); i++){
				if( nodes.get(i) == this ){
					index = i;
					break;
				}
			}
			
			return index;
		}
		
		public String toString(){
			return "Node " + nodeID;
		}
		
		@Override
		public boolean hasMoreElements() {
			return !children.isEmpty();
		}

		@Override
		public Node nextElement() {
			if( hasMoreElements() )
				return children.remove(0);
			else
				return null;
		}
	}
}
