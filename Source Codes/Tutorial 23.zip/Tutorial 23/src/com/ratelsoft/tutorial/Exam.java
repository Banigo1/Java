package com.ratelsoft.tutorial;

import java.util.ArrayList;

public class Exam {
	private String examName;
	private ArrayList<Paper> papers;
	
	public Exam(String examName){
		this.examName = examName;
		papers = new ArrayList<>();
	}
	
	public void addPaper(Paper paper){
		papers.add(paper);
	}
	
	public Paper[] getPapers(){
		return papers.toArray(new Paper[0]);
	}
	
	public String toString(){
		return examName;
	}
}
