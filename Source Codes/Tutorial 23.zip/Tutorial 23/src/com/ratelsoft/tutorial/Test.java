package com.ratelsoft.tutorial;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;

public class Test {
	private JTree tree;
	private MyTreeModel treeModel;
	private DefaultMutableTreeNode rootNode;
	private ArrayList<Exam> exams;
	
	public static void main(String[] args){
		new Test();
	}

	public Test(){
		exams = new ArrayList<>();
		JFrame frame = new JFrame("JTree Test");
		
		JPanel panel = new JPanel(new BorderLayout());
		frame.setContentPane(panel);
		
		buildTree();
		
		panel.add(tree);
		
		frame.setSize(100, 200);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	private void buildTree(){
		rootNode = new DefaultMutableTreeNode("All Items");
		
		treeModel = new MyTreeModel(rootNode);
		tree = new JTree(treeModel);
		tree.setCellRenderer(new MyTreeRenderer());
		
		tree.setRootVisible(false);
		tree.setShowsRootHandles(true);
		tree.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tree.setExpandsSelectedPaths(true);
		
		tree.addTreeSelectionListener(e -> {
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				
				if( node == null )
					return;
				
		});
		

	}
	
	private class MyTreeModel extends DefaultTreeModel{
		public MyTreeModel(DefaultMutableTreeNode root){
			super(root);
			refresh();
		}
		
		@Override
		public boolean isLeaf(Object obj) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) obj;
			
			return node.getUserObject() instanceof Paper;
		}
		
		@Override
		public int getChildCount(Object parent) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) parent;
			
			if( node.getUserObject() instanceof String ){
				return exams.size();
			}
			else if(node.getUserObject() instanceof Exam){
				return ((Exam) node.getUserObject()).getPapers().length;
			}
			
			return 0;
		}
		
		@Override
		public Object getChild(Object parent, int index) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) parent;
			
			if( node.getUserObject() instanceof String ){
				return new DefaultMutableTreeNode(exams.get(index));
			}
			else if(node.getUserObject() instanceof Exam){
				return new DefaultMutableTreeNode(((Exam) node.getUserObject()).getPapers()[index]);
			}
			
			return null;
		}
		
		public void refresh(){
			Exam exam1 = new Exam("Exam 1");
			Exam exam2 = new Exam("Exam 2");
			
			Paper p1 = new Paper("Math");
			Paper p2 = new Paper("English");
			Paper p3 = new Paper("Physics");
			
			exams.clear();
			
			exam1.addPaper(p1);
			exam2.addPaper(p2);
			exam2.addPaper(p3);
			
			exams.add(exam1);
			exams.add(exam2);
			
			reload(rootNode);
		}
	}
	
	private class MyTreeRenderer extends DefaultTreeCellRenderer{
		private JLabel label;
		private Color[] colors = {new Color(0xDDDDDD), new Color(0xEEEEEE)};
		private ImageIcon examIcon = new ImageIcon(Test.class.getResource("activate16.png"));
		private ImageIcon paperIcon = new ImageIcon(Test.class.getResource("calculator.png"));
		
		public MyTreeRenderer() {
			label = new JLabel();
			label.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
			label.setOpaque(true);
		}
		
		@Override
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
				boolean leaf, int row, boolean hasFocus) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
			label.setText(node.getUserObject().toString());
			
			if( sel ){
				label.setBackground(Color.BLUE);
			}
			else{
				if( row % 2 == 0 )
					label.setBackground(colors[0]);
				else
					label.setBackground(colors[1]);
			}
			
			if( node.getUserObject() instanceof Exam )
				label.setIcon(examIcon);
			else if( node.getUserObject() instanceof Paper )
				label.setIcon(paperIcon);
			
			
			return label;
		}
	}
}
