package com.ratelsoft.tutorial;

public class Paper {
	private String paperName;
	
	public Paper(String name) {
		paperName = name;
	}
	
	public String toString(){
		return paperName;
	}
}
