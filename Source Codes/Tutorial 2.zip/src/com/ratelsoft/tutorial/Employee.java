package com.ratelsoft.tutorial;

public class Employee {
	private final int employeeCode;
	private String employeeName;
	protected double salary;
	public static String department = "TECHNICAL";
	
	public Employee(int code, String name, double wages){
		employeeCode = code;
		employeeName = name;
		salary = wages;
	}
	
	public int getEmployeeCode(){
		return employeeCode;
	}
	
	public double getSalary(){
		return salary;
	}
}