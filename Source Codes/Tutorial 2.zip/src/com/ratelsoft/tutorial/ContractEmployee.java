package com.ratelsoft.tutorial;

public class ContractEmployee extends Employee{
	private int duration;

	public ContractEmployee(int code, String name, double wages, int duration) {
		super(code, name, wages);
		this.duration = duration;
		salary = 89;
	}
	

}
