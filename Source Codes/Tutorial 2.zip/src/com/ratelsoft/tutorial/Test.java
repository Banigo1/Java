package com.ratelsoft.tutorial;

import javax.swing.JOptionPane;

public class Test {
	public static void main(String[] args){
		/*
		Employee emp = new Employee(1001, "James Smith", 1000);
		ContractEmployee cEmp = new ContractEmployee(1000, "Paul Allen", 200, 20);
		
		System.out.println(cEmp.getSalary());
		System.out.println(emp.getSalary());
		*/
		
		
		String name = JOptionPane.showInputDialog("Insert your name:");
		JOptionPane.showMessageDialog(null, "Your name is " + name);
	}
}
