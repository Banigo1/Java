package com.ratelsoft.tutorial;

/**
 * This class models a customer's SmartPhone account details
 * @author Richboy
 * @version 11-03-2015
 */

public class SmartPhone {
	private String customerName;
	private double accountBalance;
	private int accountType;
	public static final int CheapCall = 1;
	public static final int CheapText = 2;
	private static final double cheapCallCallCost = 0.17;
	private static final double cheapCallTextCost = 12;
	private static final double cheapTextCallCost = 0.25;
	private static final double cheapTextTextCost = 8;
	
	public SmartPhone(String name, double initialBalance, int type){
		createNewAccount(name, initialBalance, type);
	}
	
	public void createNewAccount(String name, double initialBalance, int type){
		customerName = name;
		accountBalance = initialBalance >= 0 ? initialBalance : 0;
		accountType = type == CheapCall || type == CheapText ? type : CheapCall;
	}
	
	/**
	 * This method adds an amount to the customers current balance and simulates a topup
	 * @param amount the amount to add to the current balance
	 */
	public void topup(double amount){
		accountBalance += amount > 0 ? amount : 0;
	}
	
	public boolean deductCallCost(int seconds){
		switch( accountType ){
			case CheapCall: 
				if( seconds * cheapCallCallCost <= accountBalance ){
					accountBalance -= seconds * cheapCallCallCost;
					return true;
				}
			case CheapText: 
				if( seconds * cheapTextCallCost <= accountBalance ){
					accountBalance -= seconds * cheapTextCallCost; 
					return true;
				}
		}
		return false;
	}
	
	public boolean deductSMSCost(){
		switch( accountType ){
			case CheapCall: 
				if( cheapCallTextCost <= accountBalance ){
					accountBalance -= cheapCallTextCost;
					return true;
				}
			case CheapText: 
				if( cheapTextTextCost <= accountBalance ){
					accountBalance -= cheapTextTextCost;
					return true;
				}
		}
		return false;
	}
	
	public boolean purchaseApp(double cost){
		if( cost <= accountBalance ){
			accountBalance -= cost;
			return true;
		}
		
		return false;
	}
	
	public String getCurrentBalance(){
		return "£" + String.format("%.2f", accountBalance / 100);
	}
	
	public String toString(){
		return "Customer Name: " + customerName +
				", Account Type: " + (accountType == CheapCall ? "Cheap Call" : "Cheap Text") +
				", Account Balance: " + accountBalance;
	}
	
	public double refund(){
		double amount = accountBalance;
		accountBalance = 0;
		
		return amount;
	}
	
	public boolean transfer(double amount, SmartPhone phone){
		if( amount <= accountBalance ){
			accountBalance -= amount;
			phone.topup(amount);
			return true;
		}
		
		return false;
	}
	
	public String getCustomerName(){
		return customerName;
	}
}
