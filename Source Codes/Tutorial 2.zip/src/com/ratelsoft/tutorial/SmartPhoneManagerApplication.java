package com.ratelsoft.tutorial;

import javax.swing.JOptionPane;

public class SmartPhoneManagerApplication {
	private static final String EXIT = "0";
	
	public static void main(String[] args){
		String name = JOptionPane.showInputDialog("Welcome! What is your name?");
		String initialBalance = JOptionPane.showInputDialog("Please enter your initial balance:");
		
		while( true ){
			try{
				Double.parseDouble(initialBalance);
				break;
			}
			catch(Exception e){
				JOptionPane.showMessageDialog(null, "Invalid input. Please try again.\n" + e.getMessage());
				initialBalance = JOptionPane.showInputDialog("Please enter your initial balance:");
			}
		}
		
		String accountType = JOptionPane.showInputDialog("Which account type do you prefer?\n1 = CheapCall\n2 = CheapText");
		
		SmartPhone sp = new SmartPhone(name, Double.parseDouble(initialBalance), Integer.parseInt(accountType));
		
		String selection = "";
		
		do{
			selection = JOptionPane.showInputDialog("Please Select an option from the menu.\n\n"
					+ "1 = Topup Balance\n"
					+ "2 = Make Call\n"
					+ "3 = Send Text\n"
					+ "4 = Purchase an App\n"
					+ "5 = Display Balance\n"
					+ "6 = Display Account Details\n"
					+ "7 = Refund Balance\n"
					+ "8 = Transfer Money\n"
					+ "0 = Exit");
			
			try{
				int option = Integer.parseInt(selection);
				String amount;
				boolean status;
			
				switch( option ){
					case 1: 
						amount = JOptionPane.showInputDialog("Enter Topup amount:");
						sp.topup(Double.parseDouble(amount));
						break;
					case 2:
						String seconds = JOptionPane.showInputDialog("Enter the call time in seconds:");
						status = sp.deductCallCost(Integer.parseInt(seconds));
						if( !status ){
							JOptionPane.showMessageDialog(null, "Sorry you have insufficient balance");
						}
						break;
					case 3:
						status = sp.deductSMSCost();
						if( !status ){
							JOptionPane.showMessageDialog(null, "Sorry you have insufficient balance");
						}
						break;
					case 4:
						amount = JOptionPane.showInputDialog("Enter App amount:");
						status = sp.purchaseApp(Double.parseDouble(amount));
						if( !status ){
							JOptionPane.showMessageDialog(null, "Sorry you have insufficient balance");
						}
						break;
					case 5:
						JOptionPane.showMessageDialog(null, "Your balance is " + sp.getCurrentBalance());
						break;
					case 6:
						JOptionPane.showMessageDialog(null, sp.toString());
						break;
					case 7:
						double refundAmount = sp.refund();
						JOptionPane.showMessageDialog(null, "£" + (refundAmount / 100) + " has been refunded to you.");
						break;
					case 8:
						SmartPhone dummy = new SmartPhone("James Bond", 0, SmartPhone.CheapCall);
						amount = JOptionPane.showInputDialog("Enter the amount you wish to transfer to " + dummy.getCustomerName());
						status = sp.transfer(Double.parseDouble(amount), dummy);
						if( !status ){
							JOptionPane.showMessageDialog(null, "Sorry you have insufficient balance");
						}
						break;
				}
			}
			catch(Exception e){
				JOptionPane.showMessageDialog(null, "Invalid input. Please try again!");
			}
		}while( selection == null || !selection.equals(EXIT) );
	}
}
