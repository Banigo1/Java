package com.ratelsoft.tutorial;

import java.sql.ResultSet;
import java.util.LinkedList;

import javax.swing.table.AbstractTableModel;

public class MyTableModel2 extends AbstractTableModel{
	private Query q;
	String[] header= {"S/N", "ID", "Name", "Phone", "Email"};
	private LinkedList<RowData> data;
	private int selectedRow;
	private Test test;
	
	public MyTableModel2(String query, Test test) {
		data = new LinkedList<>();
		this.test = test;
		setQuery(query);
	}
	
	public void setQuery(String query){
		data.clear();
		test.deactivateDeleteButton();
		
		try{
			q = new Query(query);
			
			if( q.isConnected() ){
				ResultSet rs = q.getPS().executeQuery();
				int count = 1;
				while( rs.next() ){
					RowData d = new RowData();
					d.serialNo = count++;
					d.ID = rs.getInt("id");
					d.name = rs.getString("name");
					d.phone = rs.getString("phone");
					d.email = rs.getString("email");
					
					data.add(d);
				}
				rs.close();
			}
			
			q.disconnect();
		}
		catch(Exception e){
		}
		
		fireTableDataChanged();
	}
	
	@Override
	public int getColumnCount() {
		return header.length;
	}

	@Override
	public int getRowCount() {
		return data.size();
	}
	
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		selectedRow = rowIndex;
		test.activateDeleteButton();
		return false;
	}
	
	public void deleteSelectedRow(){
		Query q = new Query("DELETE FROM test WHERE id = " + data.get(selectedRow).ID);
		try{
			q.getPS().executeUpdate();
		}
		catch(Exception e){}
		
		q.disconnect();
	}
	
	@Override
	public String getColumnName(int column) {
		return header[column];
	}

	@Override
	public Object getValueAt(int row, int col) {
		RowData d = data.get(row);
		
		switch( col ){
			case 0: return d.serialNo;
			case 1: return d.ID;
			case 2: return d.name;
			case 3: return d.phone;
			case 4: return d.email;
			default: return "";
		}
	}

	private class RowData{
		private int ID, serialNo;
		private String name, phone, email;
	}
}
