package com.ratelsoft.tutorial;

public class Util {
	public static String DB_PATH;
}
